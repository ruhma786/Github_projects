import 'package:flutter/material.dart';


// Home Screen Placeholder

// Home Screen
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    ChatsScreen(),
    GroupsScreen(),
    UserAnnouncementsScreen(),
    SettingsScreen(),
   // NoticeBoardScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        backgroundColor: Colors.blue.shade400,
        actions: [
          IconButton(
            icon: Icon(Icons.person),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => UserProfileScreen()),
              );
            },
          ),
        ],
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        selectedItemColor: Colors.blue.shade400,
        unselectedItemColor: Colors.grey,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'Chats',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.group),
            label: 'Groups',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.announcement),
            label: 'Announcements',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Setting',
          ),
        ],
      ),
    );
  }
}

// Chat Screen (One-on-One & Groups)
class ChatsScreen extends StatelessWidget {
  final List<String> recentChats = ["John Doe", "Sarah Connor", "Group A", "Team Work", "Student Council"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chats'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Search Chats',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: recentChats.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.blue.shade100,
                    child: Icon(Icons.person, color: Colors.blue.shade400),
                  ),
                  title: Text(recentChats[index], style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  subtitle: Text('Last message here...'),
                  trailing: Icon(Icons.chevron_right, color: Colors.blue.shade400),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ChatDetailScreen(userName: recentChats[index])),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ChatDetailScreen extends StatelessWidget {
  final String userName;
  ChatDetailScreen({required this.userName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(userName),
        backgroundColor: Colors.blue.shade400,
        actions: [
          IconButton(
            icon: Icon(Icons.call),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.video_call),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: ListView(children: [ListTile(title: Text('Hello!'))])),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                IconButton(icon: Icon(Icons.photo), onPressed: () {}),
                IconButton(icon: Icon(Icons.attach_file), onPressed: () {}),
                Expanded(
                  child: TextField(decoration: InputDecoration(hintText: 'Type a message...')),
                ),
                IconButton(icon: Icon(Icons.send), onPressed: () {}),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Group Management Screen
class GroupsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Groups'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Center(child: Text('Manage Groups')),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => CreateGroupScreen()));
        },
        backgroundColor: Colors.blue.shade400,
        child: Icon(Icons.add),
      ),
    );
  }
}

class CreateGroupScreen extends StatelessWidget {
  final TextEditingController groupNameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Group'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: groupNameController,
              decoration: InputDecoration(labelText: 'Group Name'),
            ),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(labelText: 'Group Purpose'),
              maxLines: 4,
            ),
            // Member addition would be more complex, ideally showing contacts
            ElevatedButton(
              onPressed: () {
                // Logic to create group
              },
              child: Text('Create Group'),
            ),
          ],
        ),
      ),
    );
  }
}
// Dummy data for announcements (shared with the admin screen)
List<String> announcements = [
  'Announcement 1',
  'Announcement 2',
  'Announcement 3',
];

class UserAnnouncementsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Announcements'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: announcements.isEmpty
          ? Center(
        child: Text(
          'No announcements available.',
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
      )
          : ListView.builder(
        itemCount: announcements.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                announcements[index],
                style: TextStyle(fontSize: 16),
              ),
            ),
          );
        },
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: UserAnnouncementsScreen(),
  ));
}

// User Profile Screen
class UserProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Profile'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Center(
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              backgroundColor: Colors.blue.shade400,
              child: Icon(Icons.person, size: 50, color: Colors.white),
            ),
            SizedBox(height: 20),
            Text('John Doe', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text('Department: Computer Science'),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                // Logic to log out
              },
              child: Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}

// Settings & Notifications Screen
class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings & Notifications'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Column(
        children: [
          ListTile(
            title: Text('Chat Notifications'),
            trailing: Switch(value: true, onChanged: (value) {}),
          ),
          ListTile(
            title: Text('Group Notifications'),
            trailing: Switch(value: true, onChanged: (value) {}),
          ),
          ListTile(
            title: Text('Clear Chat History'),
            trailing: IconButton(icon: Icon(Icons.delete), onPressed: () {}),
          ),
          ListTile(
            title: Text('Logout'),
            trailing: IconButton(icon: Icon(Icons.exit_to_app), onPressed: () {}),
          ),
        ],
      ),
    );
  }
}

// Password Reset Screen
class PasswordResetScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Password Reset'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: 'Enter your email'),
            ),
            ElevatedButton(
              onPressed: () {
                // Logic to send reset link
              },
              child: Text('Send Reset Link'),
            ),
          ],
        ),
      ),
    );
  }
}
