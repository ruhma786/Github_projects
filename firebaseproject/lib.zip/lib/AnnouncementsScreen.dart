import 'package:flutter/material.dart';

// Dummy data for announcements
List<String> announcements = [
  'Announcement 1',
  'Announcement 2',
  'Announcement 3',
];

class AnnouncementsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Announcements'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () {
                // Navigate to Create Announcement Screen
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CreateAnnouncementScreen()),
                );
              },
              child: Text('Create Announcement'),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: announcements.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(announcements[index]),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () {
                          // Navigate to edit screen and pass the announcement to edit
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => EditAnnouncementScreen(
                                announcement: announcements[index],
                                index: index,
                              ),
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          // Delete the announcement
                          announcements.removeAt(index);
                          (context as Element).markNeedsBuild(); // Refresh the list
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class CreateAnnouncementScreen extends StatefulWidget {
  @override
  _CreateAnnouncementScreenState createState() =>
      _CreateAnnouncementScreenState();
}

class _CreateAnnouncementScreenState extends State<CreateAnnouncementScreen> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController contentController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Announcement'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            TextField(
              controller: contentController,
              decoration: InputDecoration(labelText: 'Content'),
              maxLines: 4,
            ),
            ElevatedButton(
              onPressed: () {
                // Logic to post announcement
                setState(() {
                  announcements.add(titleController.text);
                });
                Navigator.pop(context); // Go back to the previous screen
              },
              child: Text('Post Announcement'),
            ),
          ],
        ),
      ),
    );
  }
}

class EditAnnouncementScreen extends StatefulWidget {
  final String announcement;
  final int index;

  EditAnnouncementScreen({required this.announcement, required this.index});

  @override
  _EditAnnouncementScreenState createState() =>
      _EditAnnouncementScreenState();
}

class _EditAnnouncementScreenState extends State<EditAnnouncementScreen> {
  late TextEditingController titleController;

  @override
  void initState() {
    super.initState();
    titleController = TextEditingController(text: widget.announcement);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Announcement'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            ElevatedButton(
              onPressed: () {
                // Update the announcement
                setState(() {
                  announcements[widget.index] = titleController.text;
                });
                Navigator.pop(context); // Go back to the announcements list
              },
              child: Text('Update Announcement'),
            ),
          ],
        ),
      ),
    );
  }
}
