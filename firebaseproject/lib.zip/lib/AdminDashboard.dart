import 'package:flutter/material.dart';
import 'AnnouncementsScreen.dart'; // The screen to show and manage announcements

class AdminDashboard extends StatelessWidget {
  final String email;

  AdminDashboard({required this.email});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard'),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Welcome, Admin!',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Text(
              'Logged in as: $email',
              style: TextStyle(fontSize: 16, color: Colors.black87),
            ),
            SizedBox(height: 24),
            Expanded(
              child: ListView(
                children: [
                  ListTile(
                    leading: Icon(Icons.group, color: Colors.blue),
                    title: Text('Manage Users'),
                    subtitle: Text('Add or remove users from the system.'),
                    onTap: () {
                      // Navigate to Manage Users Screen
                    },
                  ),
                  Divider(),
                  ListTile(
                    leading: Icon(Icons.announcement, color: Colors.blue),
                    title: Text('Manage Announcements'),
                    subtitle: Text('Create, edit, or delete announcements.'),
                    onTap: () {
                      // Navigate to the Announcement Management Screen
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AnnouncementsScreen(),
                        ),
                      );
                    },
                  ),
                  Divider(),
                  ListTile(
                    leading: Icon(Icons.settings, color: Colors.blue),
                    title: Text('System Settings'),
                    subtitle: Text('Configure app settings and preferences.'),
                    onTap: () {
                      // Navigate to System Settings Screen
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
