import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'EmailVerficationscreen.dart';
import 'Homescreen.dart';
import 'AdminDashboard.dart';

class LoginSignupScreen extends StatefulWidget {
  @override
  _LoginSignupScreenState createState() => _LoginSignupScreenState();
}

class _LoginSignupScreenState extends State<LoginSignupScreen> {
  bool isLogin = true;
  bool showPassword = false;

  final _formKey = GlobalKey<FormState>();

  // Controllers for login and signup
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  void handleLoginSignup() async {
    if (_formKey.currentState!.validate()) {
      final email = emailController.text.trim();
      final password = passwordController.text.trim();

      try {
        if (isLogin) {
          // Admin login check
          if (email == 'docs@cuivehari.edu.pk' || email == 'hodcs@cuivehari.edu.pk') {
            await _auth.signInWithEmailAndPassword(email: email, password: password);
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => AdminDashboard(email: email)),
            );
          } else {
            // Non-admin user login
            await _auth.signInWithEmailAndPassword(email: email, password: password);
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => HomeScreen()),
            );
          }
        } else {
          // Handle signup
          String name = nameController.text.trim();
          String confirmPassword = confirmPasswordController.text.trim();

          if (!email.endsWith("@cuivehari.edu.pk")) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Please use a valid @cuivehari.edu.pk email.")),
            );
            return;
          }

          if (password != confirmPassword) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Passwords do not match.")),
            );
            return;
          }

          UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
            email: email,
            password: password,
          );

          // Store user information in Firestore
          await _firestore.collection('Users').doc(userCredential.user?.uid).set({
            'name': name,
            'email': email,
            'createdAt': FieldValue.serverTimestamp(),
          });

          // Send email verification
          await userCredential.user?.sendEmailVerification();

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => EmailVerificationScreen()),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                isLogin ? "Login" : "Signup",
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              if (!isLogin)
                TextFormField(
                  controller: nameController,
                  decoration: InputDecoration(labelText: "Name"),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "Please enter your name.";
                    }
                    return null;
                  },
                ),
              TextFormField(
                controller: emailController,
                decoration: InputDecoration(labelText: "Email"),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Please enter your email.";
                  } else if (!value.endsWith("@cuivehari.edu.pk")) {
                    return "Email must end with @cuivehari.edu.pk.";
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: passwordController,
                obscureText: !showPassword,
                decoration: InputDecoration(
                  labelText: "Password",
                  suffixIcon: IconButton(
                    icon: Icon(showPassword ? Icons.visibility : Icons.visibility_off),
                    onPressed: () => setState(() => showPassword = !showPassword),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Please enter your password.";
                  }
                  return null;
                },
              ),
              if (!isLogin)
                TextFormField(
                  controller: confirmPasswordController,
                  obscureText: true,
                  decoration: InputDecoration(labelText: "Confirm Password"),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "Please confirm your password.";
                    }
                    return null;
                  },
                ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: handleLoginSignup,
                child: Text(isLogin ? "Login" : "Signup"),
              ),
              if (isLogin)
                TextButton(
                  onPressed: () {
                    // Navigate to password reset screen
                  },
                  child: Text("Forgot Password?"),
                ),
              TextButton(
                onPressed: () {
                  setState(() {
                    isLogin = !isLogin;
                  });
                },
                child: Text(isLogin ? "Don't have an account? Signup" : "Already have an account? Login"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
